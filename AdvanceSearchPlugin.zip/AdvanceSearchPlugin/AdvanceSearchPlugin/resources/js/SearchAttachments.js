function searchBoxCheckEnterKeyPressed(e) {
	var key;
	if (window.event)
		key = window.event.keyCode; // IE
	else
		key = e.which; // firefox

	if (key == 13) {
		createGrid();
		return false;
	} else
		return true;
}

function createRequestParametersString() {
	var searchTerm = document.getElementById("searchTerm").value;
	var userAccountId = document.getElementById("userAccountId").value;
	var req = 'searchTerm=' + searchTerm + '&userAccountId=' + userAccountId;
	checkboxes = document.getElementsByName('exzacCriteria');
	for ( var i = 0; i < checkboxes.length; i++)
		req += '&' + checkboxes[i].id + '=' + checkboxes[i].checked;
	return req;
}

function createRequestParametersArray() {
	var params = {
		searchTerm : document.getElementById("searchTerm").value.replace('*',
				'%').replace('.', '_'),
		userAccountId : document.getElementById("userAccountId").value
	};
	checkboxes = document.getElementsByName('exzacCriteria');
	for ( var i = 0; i < checkboxes.length; i++)
		params[checkboxes[i].id] = checkboxes[i].checked;
	var url = (window.location != window.parent.location) ? document.referrer
			: document.location;
	var endPos = url.indexOf('plugin');
	params["rcmAddress"] = url.substring(0, endPos-1);
	return params;
}

function createGrid() {
	jQuery("#searchResultsGrid").jqGrid('GridUnload', "list4");

	jQuery("#searchResultsGrid")
			.jqGrid(
					{
						mtype : "POST",
						postData : createRequestParametersArray(),
						url : 'SearchAttachmentsServlet',
						datatype : "xml",
						height : 461,
						colNames : [ 'Case Id', 'File Name', 'Case Date',
								'Ref No (source)', 'Focus Name', 'Case Status',
								'Current Case Category', 'Assigned To',
								'Search Module' ],
						colModel : [ {
							name : 'Case Id',
							index : 'CASE_IDENTIFIER',
							width : 100,
							sortable : true
						}, {
							name : 'File Name',
							index : 'FILE_NAME',
							width : 250,
							sortable : true
						}, {
							name : 'Case Date',
							index : 'CASE_DATE',
							width : 40,
							sortable : true
						}, {
							name : 'Ref No (source)',
							index : 'ALERT_ID',
							width : 40,
							sortable : true
						}, {
							name : 'Focus Name',
							index : 'Focus Name',
							width : 100,
							sortable : false
						}, {
							name : 'Case Status',
							index : 'STATUS_NAME',
							width : 40,
							sortable : true
						}, {
							name : 'Current Case Category',
							index : 'Current Case Category',
							width : 100,
							sortable : false
						}, {
							name : 'Assigned To',
							index : 'FULL_NAME',
							width : 100,
							sortable : true
						}, {
							name : 'Search Module',
							index : 'Search Module',
							width : 100,
							sortable : false
						} ],
						multiselect : false,
						autowidth : true,
						caption : "Search Results",
						rowNum : 20,
						viewrecords : true,
						pager : '#pager'
					});
	jQuery("#searchResultsGrid").jqGrid('setGridParam', {
		postData : createRequestParametersArray()
	});
	jQuery("#searchResultsGrid").jqGrid('navGrid', {
		edit : false,
		add : false,
		del : false
	});
}
function toggle(source) {
	var checkboxes = document.getElementsByName('exzacCriteria');
	for ( var i = 0; i < checkboxes.length; i++)
		checkboxes[i].checked = source.checked;
}

function updateSelectAll(source) {
	var chkSelectAll = document.getElementById('chkSelectAll');
	if (source.checked == false) {
		chkSelectAll.checked = false;
	} else {
		var allChecked = true;
		var checkboxes = document.getElementsByName('exzacCriteria');
		for ( var i = 0; i < checkboxes.length; i++) {
			if (checkboxes[i].checked == false)
				allChecked = false;
		}
		chkSelectAll.checked = allChecked;
	}
}

function initMultAccordion() {

	jQuery('.accordion').accordion({collapsible:true,active:false});

}
