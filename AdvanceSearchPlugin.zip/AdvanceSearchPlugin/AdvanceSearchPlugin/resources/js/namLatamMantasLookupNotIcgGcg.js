function getCustAcctTableHeader() {
	return '<table id="tblAddCustomer" name="tblAddCustomer" style="border: thin solid #C0C0C0;width:100%;font-family: Arial, Helvetica, sans-serif; font-size: 12px">'
			+ '<tr id="headerRow" style="background-color: #CCCCFF"><td>Select</td><td><label id="Label24">Cust Name</label></td><td><label id="Label25">Role</label></td>'
			+ '<td><label id="Label26">Acct Name</label></td><td><label id="Label32">Acct ID</label></td><td><label id="Label34">TIN</label></td><td>Delete</td></tr>';
}

function AddCustomer() {
	var inputs = document.getElementsByTagName("input");
	var addcustomerHdr = document.getElementById('hidAddcustomer').value;
	var addCustomerDetailshdr = '';
	var addCustomerDetail = '';
	var counter;
	var incNo;
	var divHTML;
	var AcctStyle = '';
	var TINStyle = '';
	var focusId = '';
	var focusName = '';
	var focusType = '';

	divHTML = document.getElementById('divAddCustomer').innerHTML;

	focusType = document.getElementById('hidSearch').value;
	if (focusType == 'Account ID')
		AcctStyle = 'style="background-color: #FFCCCC"';
	else
		TINStyle = 'style="background-color: #FFCCCC"';

	counter = document.getElementById('hidcounter').value;
	if (addcustomerHdr == "false" || divHTML == '') {
		document.getElementById('hidAddcustomer').value = "true";
		addCustomerDetailshdr = getCustAcctTableHeader();
	} else {
		divHTML = divHTML.replace('</table>', ' ');
		divHTML = divHTML.replace('</TABLE>', ' ')
		divHTML = divHTML.replace('</TBODY>', ' ')
	}
	for ( var i = 0; i < inputs.length; i++) {
		if (inputs[i].type == "checkbox"
				&& inputs[i].name.substring(0, 6) == 'ChkAcc') {
			incNo = inputs[i].name.substring(6, 7);
			if (inputs[i].checked) {
				if (focusType == 'Account ID') {
					focusId = document.getElementById('lblAccID' + incNo).innerHTML;
					focusName = document.getElementById('lblAccName' + incNo).innerHTML;
				} else {
					focusId = document.getElementById('lblCustomerId' + incNo).value;
					focusName = document.getElementById('lblCustName' + incNo).innerHTML;
				}
				counter = parseInt(counter) + 1;
				addCustomerDetail = addCustomerDetail
						+ '<tr><td><input id="radSelect'
						+ counter
						+ '" type="radio" name="radSelect" value="'
						+ focusType
						+ '" onclick="javascript:selectFocus(\''
						+ focusId
						+ '\',\''
						+ focusName
						+ '\',\''
						+ focusType
						+ '\');" /></td>'
						+ '<td><input type="hidden" id="lblfIsManual'
						+ counter
						+ '"  name="lblfIsManual" value="false">'
						+ '<input type="hidden" id="lblfAccountSeqId'
						+ counter
						+ '"  name="lblfAccountSeqId" value="'
						+ document.getElementById('lblAccountSeqId' + incNo).value
						+ '">'
						+ '<input type="hidden" id="lblfCustomerSeqId'
						+ counter
						+ '"  name="lblfCustomerSeqId" value="'
						+ document.getElementById('lblCustomerSeqId' + incNo).value
						+ '">'
						+ '<input type="hidden" id="lblfCustomerId'
						+ counter
						+ '"  name="lblfCustomerId" value="'
						+ document.getElementById('lblCustomerId' + incNo).value
						+ '">'
						+ '<label id="lblfcustname'
						+ counter
						+ '"  name="lblfcustname">'
						+ document.getElementById('lblCustName' + incNo).innerHTML
						+ '</label></td>'
						+ '<td><label id="lblfRole'
						+ counter
						+ '" name="lblfRole">'
						+ document.getElementById('lblRole' + incNo).innerHTML
						+ '</label></td>'
						+ '<td><label id="lblfAccName'
						+ counter
						+ '" name="lblfAccName">'
						+ document.getElementById('lblAccName' + incNo).innerHTML
						+ '</label></td>'
						+ '<td><label id="lblfAccID'
						+ counter
						+ '" name="lblfAccID" '
						+ AcctStyle
						+ '>'
						+ document.getElementById('lblAccID' + incNo).innerHTML
						+ '</label></td>'
						+ '<td><label id="lblfTIN'
						+ counter
						+ '" name="lblfTIN" '
						+ TINStyle
						+ ' >'
						+ document.getElementById('lblTIN' + incNo).innerHTML
						+ '</label></td>'
						+ '<td><input id="btnDelete'
						+ counter
						+ '" name="btnDelete" type="button" value="Delete" onclick="deleteRow(this)" /></td></tr>';

			}
		}

	}
	document.getElementById('hidcounter').value = counter;
	document.getElementById('divAddCustomer').innerHTML = divHTML
			+ addCustomerDetailshdr + addCustomerDetail + '</table>';

}

function AddCustomer_m() {
	var addcustomerHdr = document.getElementById('hidAddcustomer').value;
	var addCustomerDetailshdr = '';
	var addCustomerDetail = '';
	var counter = document.getElementById('hidcounter').value;
	var incNo;
	var divHTML;
	var AccName = '';
	var CustName = '';
	var FCID = '';
	var AcctStyle = '';
	var TINStyle = '';
	var focusId = '';
	var focusName = '';

	divHTML = document.getElementById('divAddCustomer').innerHTML;

	if (addcustomerHdr == "false" || divHTML == '') {
		document.getElementById('hidAddcustomer').value = "true";
		addCustomerDetailshdr = getCustAcctTableHeader();
	} else {
		divHTML = divHTML.replace('</table>', ' ');
		divHTML = divHTML.replace('</TABLE>', ' ');
		divHTML = divHTML.replace('</TBODY>', ' ');
	}
	if ((document.getElementById('txtmAccNo').value != '' && document
			.getElementById('radAcc').checked == true)
			|| (document.getElementById('txtmSSN').value != '' && document
					.getElementById('radCust').checked == true)) {
		counter = parseInt(counter) + 1;

		if (document.getElementById('radAcc').checked == true) {
			AccName = document.getElementById('txtmAccName').value;
			focusName = AccName;
			focusId = document.getElementById('txtmAccNo').value;
			FCID = 'Account ID';
			AcctStyle = 'style="background-color: #FFCCCC"';
		} else {
			CustName = document.getElementById('txtmAccName').value;
			focusName = CustName;
			focusId = document.getElementById('txtmSSN').value;
			FCID = 'TIN';
			TINStyle = 'style="background-color: #FFCCCC"';
		}

		addCustomerDetail = addCustomerDetail
				+ '<tr><td><input id="radSelect'
				+ counter
				+ '"  type="radio" name="radSelect" value="'
				+ FCID
				+ '" onclick="javascript:selectFocus(\''
				+ focusId
				+ '\',\''
				+ focusName
				+ '\',\''
				+ FCID
				+ '\');" /></td>'
				+ '<td><input type="hidden" id="lblfIsManual'
				+ counter
				+ '"  name="lblfIsManual" value="true">'
				+ '<label id="lblfcustname'
				+ counter
				+ '" name="lblfcustname">'
				+ CustName
				+ '</label></td>'
				+ '<td><label id="lblfRole'
				+ counter
				+ '" name="lblfRole"></label></td>'
				+ '<td><label id="lblfAccName'
				+ counter
				+ '" name="lblfAccName">'
				+ AccName
				+ '</label></td>'
				+ '<td><label id="lblfAccID'
				+ counter
				+ '" name="lblfAccID" '
				+ AcctStyle
				+ '>'
				+ document.getElementById('txtmAccNo').value
				+ '</label></td>'
				+ '<td><label id="lblfTIN'
				+ counter
				+ '" name="lblfTIN" '
				+ TINStyle
				+ '>'
				+ document.getElementById('txtmSSN').value
				+ '</label></td>'
				+ '<td><input id="btnDelete'
				+ counter
				+ '" name="btnDelete" type="button" value="Delete" onclick="deleteRow(this)" /></td></tr>';

		AccName = '';
		CustName = '';
		FCID = '';
		resetManual();
	}
	if ((document.getElementById('txtmAccNo1').value != '' && document
			.getElementById('radAcc1').checked == true)
			|| (document.getElementById('txtmSSN1').value != '' && document
					.getElementById('radCust1').checked == true)) {
		counter = parseInt(counter) + 1;
		if (document.getElementById('radAcc1').checked == true) {
			AccName = document.getElementById('txtmAccName1').value;
			focusName = AccName;
			focusId = document.getElementById('txtmAccNo1').value;
			FCID = 'Account ID';
			AcctStyle = 'style="background-color: #FFCCCC"';
		} else {
			CustName = document.getElementById('txtmAccName1').value;
			focusName = CustName;
			focusId = document.getElementById('txtmSSN1').value;
			FCID = 'TIN';
			TINStyle = 'style="background-color: #FFCCCC"';
		}

		addCustomerDetail = addCustomerDetail
				+ '<tr><td><input id="radSelect'
				+ counter
				+ '"  type="radio" name="radSelect"  value="'
				+ FCID
				+ '" onclick="javascript:selectFocus(\''
				+ focusId
				+ '\',\''
				+ focusName
				+ '\',\''
				+ FCID
				+ '\');"/></td>'
				+ '<td><input type="hidden" id="lblfIsManual'
				+ counter
				+ '"  name="lblfIsManual" value="true">'
				+ '<label id="lblfcustname'
				+ counter
				+ '" name="lblfcustname">'
				+ CustName
				+ '</label></td>'
				+ '<td><label id="lblfRole'
				+ counter
				+ '" name="lblfRole"></label></td>'
				+ '<td><label id="lblfAccName'
				+ counter
				+ '" name="lblfAccName">'
				+ AccName
				+ '</label></td>'
				+ '<td><label id="lblfAccID'
				+ counter
				+ '" name="lblfAccID" '
				+ AcctStyle
				+ '>'
				+ document.getElementById('txtmAccNo1').value
				+ '</label></td>'
				+ '<td><label id="lblfTIN'
				+ counter
				+ '" name="lblfTIN" '
				+ TINStyle
				+ '>'
				+ document.getElementById('txtmSSN1').value
				+ '</label></td>'
				+ '<td><input id="btnDelete'
				+ counter
				+ '" name="btnDelete" type="button" value="Delete" onclick="deleteRow(this)" /></td></tr>';

		AccName = '';
		CustName = '';
		FCID = '';
		resetManual1();
	}
	if ((document.getElementById('txtmAccNo2').value != '' && document
			.getElementById('radAcc2').checked == true)
			|| (document.getElementById('txtmSSN2').value != '' && document
					.getElementById('radCust2').checked == true)) {
		counter = parseInt(counter) + 1;
		if (document.getElementById('radAcc2').checked == true) {
			AccName = document.getElementById('txtmAccName2').value;
			focusName = AccName;
			focusId = document.getElementById('txtmAccNo2').value;
			FCID = 'Account ID';
			AcctStyle = 'style="background-color: #FFCCCC"';
		} else {
			CustName = document.getElementById('txtmAccName2').value;
			focusName = CustName;
			focusId = document.getElementById('txtmSSN2').value;
			FCID = 'TIN';
			TINStyle = 'style="background-color: #FFCCCC"';
		}

		addCustomerDetail = addCustomerDetail
				+ '<tr><td><input id="radSelect'
				+ counter
				+ '"  type="radio" name="radSelect"  value="'
				+ FCID
				+ '" onclick="javascript:selectFocus(\''
				+ focusId
				+ '\',\''
				+ focusName
				+ '\',\''
				+ FCID
				+ '\');"/></td>'
				+ '<td><input type="hidden" id="lblfIsManual'
				+ counter
				+ '"  name="lblfIsManual" value="true">'
				+ '<label id="lblfcustname'
				+ counter
				+ '" name="lblfcustname">'
				+ CustName
				+ '</label></td>'
				+ '<td><label id="lblfRole'
				+ counter
				+ '" name="lblfRole"></label></td>'
				+ '<td><label id="lblfAccName'
				+ counter
				+ '" name="lblfAccName">'
				+ AccName
				+ '</label></td>'
				+ '<td><label id="lblfAccID'
				+ counter
				+ '" name="lblfAccID" '
				+ AcctStyle
				+ '>'
				+ document.getElementById('txtmAccNo2').value
				+ '</label></td>'
				+ '<td><label id="lblfTIN'
				+ counter
				+ '" name="lblfTIN" '
				+ TINStyle
				+ '>'
				+ document.getElementById('txtmSSN2').value
				+ '</label></td>'
				+ '<td><input id="btnDelete'
				+ counter
				+ '" name="btnDelete" type="button" value="Delete" onclick="deleteRow(this)" /></td></tr>';
		resetManual2();
	}
	document.getElementById('hidcounter').value = counter;
	document.getElementById('divAddCustomer').innerHTML = divHTML
			+ addCustomerDetailshdr + addCustomerDetail + '</table>';

}
function resetManual() {
	document.getElementById('txtmAccNo').value = '';
	document.getElementById('txtmAccName').value = '';
	document.getElementById('txtmSSN').value = '';
}
function resetManual1() {
	document.getElementById('txtmAccNo1').value = '';
	document.getElementById('txtmAccName1').value = '';
	document.getElementById('txtmSSN1').value = '';
}
function resetManual2() {
	document.getElementById('txtmAccNo2').value = '';
	document.getElementById('txtmAccName2').value = '';
	document.getElementById('txtmSSN2').value = '';

}

function deleteRow(r) {
	var i = r.parentNode.parentNode.rowIndex;
	document.getElementById('tblAddCustomer').deleteRow(i);
}

function resetSearch() {

	document.frmSearch.txtACCID.value = '';
	document.frmSearch.txtTIN.value = '';
}

function addPluginParametersForRow(row, id) {
	var paramValue = '';
	paramValue += row.find('[name="radSelect"]').attr('checked') + ';';
	paramValue += row.find('[name="lblfIsManual"]').attr('value') + ';';
	paramValue += row.find('[name="lblfcustname"]').html() + ';';
	paramValue += row.find('[name="lblfRole"]').html() + ';';
	paramValue += row.find('[name="lblfAccName"]').html() + ';';
	paramValue += row.find('[name="lblfAccID"]').html() + ';';
	paramValue += row.find('[name="lblfTIN"]').html();
	if (row.find('[name="lblfIsManual"]').attr('value') == 'false') {
		paramValue += ';' + row.find('[name="lblfAccountSeqId"]').attr('value')
				+ ';';
		paramValue += row.find('[name="lblfCustomerSeqId"]').attr('value')
				+ ';';
		paramValue += row.find('[name="lblfCustomerId"]').attr('value');
	}
	setPluginParameter(id, paramValue);
}

function addCustomersAndAccountsPluginParams() {
	var str = '';
	var fNames = new Array();
	var fValues = new Array();
	var counter = 0;

	var rows = jQuery('#divAddCustomer').find('tr');
	for ( var i = 0; i < rows.length; i++) {
		var row = jQuery(rows[i]);
		if (row.attr('id') == 'headerRow')
			continue;
		var select = row.find('[name="radSelect"]');
		if (select.attr('value') == 'TIN') {
			addPluginParametersForRow(row, 'CustomerRecord' + i);
		} else {
			addPluginParametersForRow(row, 'AccountRecord' + i);
		}
	}

}
// <![CDATA[
function mantasLookupResultsCallback() {

	if (window.XMLHttpRequest) {

		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	var AccID = jQuery('#txtACCID').val();
	var TIN = jQuery('#txtTIN').val();

	if (AccID != '')
		document.getElementById('hidSearch').value = "Account ID";
	else
		document.getElementById('hidSearch').value = "TIN";

	if (AccID != '' || TIN != '') {
		xmlhttp.open("GET", '${accounts_mantas_cust_lookup_address}?TIN='
				+ jQuery('#txtTIN').val() + '&alternateAccountID='
				+ jQuery('#txtACCID').val() + '&bu='
				+ jQuery("#selectBU").val(), false);
		xmlhttp.send();
		if (xmlhttp.status == 200) {
			var xml = xmlhttp.responseXML;
			var isCustomer;
			var customerDeatils;
			isCustomer = false;
			customerDeatils = '';
			var customers = xml.getElementsByTagName("customer");
			if (customers.length > 0) {
				isCustomer = true;
				customerDeatils = '<table id="tblDisplay" style="border: thin solid #C0C0C0;width:100%;font-family: Arial, Helvetica, sans-serif; font-size: 12px"><tr style="background-color: #CCCCFF"><td>&nbsp;</td><td><label id="Label0">Cust Name</label></td><td><label id="Label1">Role</label></td><td><label id="Label2">Acct Name</label></td><td><label id="Label14">Acct ID</label></td><td><label id="Label3">Acct Type</label></td><td><label id="Label4">TIN</label></td><td><label id="Label5">Acct FC No</label></td><td><label id="Label6"></label></td></tr>';
			}
			for ( var i = 0; i < customers.length; i++) {
				// var Customer =
				// customers[i].getElementsByTagName('customername').textContent;
				customerDeatils = customerDeatils + '<tr >'
						+ '<td><input id="ChkAcc' + i + '" name="ChkAcc' + i
						+ '" type="checkbox" />' + '<input id="lblAccountSeqId'
						+ i + '" name="lblAccountSeqId' + i
						+ '" type="hidden" value="'
						+ customers[i].childNodes[7].text + '" />'
						+ '<input id="lblCustomerSeqId' + i
						+ '" name="lblCustomerSeqId' + i
						+ '" type="hidden" value="'
						+ customers[i].childNodes[8].text + '" />'
						+ '<input id="lblCustomerId' + i
						+ '" name="lblCustomerId' + i
						+ '" type="hidden" value="'
						+ customers[i].childNodes[9].text + '" />' + '</td>'
						+ '<td><label id="lblCustName' + i + '">'
						+ customers[i].childNodes[0].text + '</label></td>'
						+ '<td><label id="lblRole' + i + '">'
						+ customers[i].childNodes[1].text + '</label></td>'
						+ '<td><label id="lblAccName' + i + '">'
						+ customers[i].childNodes[2].text + '</label></td>'
						+ '<td><label id="lblAccID' + i + '">'
						+ customers[i].childNodes[3].text + '</label></td>'
						+ '<td><label id="lblAccType' + i + '">'
						+ customers[i].childNodes[4].text + '</label></td>'
						+ '<td><label id="lblTIN' + i + '">'
						+ customers[i].childNodes[5].text + '</label></td>'
						+ '<td><label id="lblAccFCNO' + i + '">'
						+ customers[i].childNodes[6].text
						+ '</label></td></tr>';
				// var Customer = customers[i].childNodes[0].text;
				// document.write(Customer);
			}
			if (isCustomer == true) {
				customerDeatils = customerDeatils
						+ '<tr><td colspan="9" style="text-align: right"><input id="btnAddMCust" name="btnAddMCust" type="button" value="Add Customer"  onclick="Javascript:AddCustomer();" /></td></tr></table>';
				document.getElementById('divDisplayLookupResult').innerHTML = customerDeatils;

			}

		} else if (xmlhttp.status == 404)
			alert("XML could not be found");
	}
}

function enableDisableCustAcctInputs(enableInputId, disableInputId) {
	document.getElementById(disableInputId).disabled = true;
	document.getElementById(enableInputId).disabled = false;
}

function selectFocus(focusId, focusName, focusType) {
	if (focusType == 'Account ID')
		jQuery('#selectFocusType').val("ACCOUNT");
	else
		jQuery('#selectFocusType').val("CUSTOMER");
	jQuery('#focusId').val(focusId);
	jQuery('#focusName').val(focusName);
}