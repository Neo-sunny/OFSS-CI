package com.threads;

import java.util.LinkedList;
import java.util.List;

public class ProducerConsumerSolution {

public static class ProducerConsumer{
	
	// A list shared by both producer and consumer
	List<Integer> sharedData = new LinkedList<>();
	int capacity =5;
	
	public void produce() throws InterruptedException{
		int value=0;
//		while
	}
}






}
