package com.threads;

import java.util.Scanner;

public class Lexical {

	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		String s=input.next();
		int n= input.nextInt();
		int j=n-1;
		String lexicalSmallest="";
		String lexicalLargest="";
		String[] array= new String[s.length()-j];
		for(int i=0; i<s.length()-j; i++){
			String sub=s.substring(i, n++);
			array[i]=sub;
		}
		for(String s1:array){
			if(s1.compareTo(lexicalLargest)>0){
				lexicalLargest=s1;
			}else if(s1.compareTo(lexicalSmallest)<0){
				lexicalSmallest=s1;
			}
		}
		System.out.println(lexicalLargest);
		System.out.println(lexicalSmallest);
	}
}
