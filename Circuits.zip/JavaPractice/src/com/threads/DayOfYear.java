package com.threads;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class DayOfYear {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws ParseException {
		Scanner in = new Scanner(System.in);
        String month = in.next();
        String day = in.next();
        String year = in.next();
        String urDate=year+"-"+month+"-"+day;
    	Date date= new SimpleDateFormat("yyyy-MM-dd").parse(urDate);
    	String dayOfWeek = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date);
    	System.out.println(dayOfWeek.toUpperCase());
	}
}
