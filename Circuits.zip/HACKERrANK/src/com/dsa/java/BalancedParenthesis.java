package com.dsa.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class BalancedParenthesis {

	public static void main(String[] args) throws IOException {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		String line="";
		Stack stack = new Stack();
		// To read until the end of the file
		/*Unbalancing can happen in 2 ways 
		 * It may have more Opening Braces or or more closing braces
		 * */
		int i=0;
		while((line=br.readLine())!=null){
//			System.out.println(line);
			char[] array= line.toCharArray();
	
			
			for( i=0; i<array.length; i++){
				if(array[i]=='(' || array[i]=='{' || array[i]=='['){
					stack.push(array[i]);
				}else if(array[i]==')' || array[i]=='}' || array[i]==']'){
					if(!stack.isEmpty()){
						stack.pop();
					}else{
						stack.clear();
						break;
					}
				}
			}
				if(i==array.length && stack.isEmpty()){
					System.out.println("true");
					System.out.println("value of i "+i);
				}else if(i<array.length && stack.isEmpty()){
					System.out.println("false");
					System.out.println("value of i "+i);
				}else if(i<=array.length && !stack.isEmpty()){
					System.out.println("false");
					System.out.println("value of i "+i);
					stack.clear();
				}
		}
	}
		
}