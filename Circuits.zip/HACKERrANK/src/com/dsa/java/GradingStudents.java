package com.dsa.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GradingStudents {

	public static void main(String[] args) throws IOException {
		// Find the closest multiple of 5 for a given number
		BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
		int tCases=Integer.parseInt(br.readLine());
		for(int i=0; i<tCases; i++){
		int num= Integer.parseInt(br.readLine());
		
		System.out.println(num<38 || num %5<3 ?num : num+(5- (num%5)));
		/*int q1= num/5;
		int nextMultiple=(q1+1)*5;
		int diff=nextMultiple-num;
		if(num<38){
			System.out.println(num);
		}else if(num>=38 && diff<3){
			num=nextMultiple;
			System.out.println(num);
		}
		 else if(num>=38 && diff>=3){
					System.out.println(num);
				}*/
			}
	}
	}
