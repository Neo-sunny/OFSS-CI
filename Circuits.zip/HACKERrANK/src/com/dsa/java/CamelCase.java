package com.dsa.java;

public class CamelCase {

	public static void main(String[] args) {
		String nStr= "thisIsMy�berString";
		String str= "saveChangesInTheEditor";
		String[] s1=  nStr.split("(?=\\p{Upper})");
		String[] s2=nStr.split("(?=\\p{Lu})");
		for(String str1: s2){
			System.out.println(str1);
		}
	}
}
