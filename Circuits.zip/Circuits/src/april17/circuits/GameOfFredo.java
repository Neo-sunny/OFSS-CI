package april17.circuits;

import java.util.Scanner;

public class GameOfFredo {

	public static void main(String[] args) {
	Scanner in= new Scanner(System.in);
	int tCases= in.nextInt();
	int gameEndIndex=0, j=0;
	for(int i=0; i<tCases; i++){
		int ammo=in.nextInt();
		int size=in.nextInt();
		for( j=0; j<size;j++){
			int val=in.nextInt();
			/*1.)ArrayValue is 0, ammo >0
			 *2.)ArrayValue is 1, ammo>0
			 *3.) ArrayValue is 0, ammo =0==>Game Ends; Get the Index
			 *4.)ArrayValue is 1, ammo=0 
			 * */
			if(val==0 && ammo>0){
				ammo--;
				if(ammo==0 && j==size-1) {
					gameEndIndex=j;break;// if this is the case of last index then it is wrong
				}else if(ammo==0 && j<size){
					gameEndIndex=j+1;break;
				}
			}
			else if(val==1 && ammo>0){
				ammo+=2;
			}
			else if(val==0 && ammo==0){
				gameEndIndex=j+1;
				break;
			}
			else if(val==1 && ammo==0){
				ammo+=2;
			}
		}
		if(j==size){ System.out.println("Yes  "+ammo);}
		else if(gameEndIndex<size && ammo==0 ){System.out.println("Yes "+ gameEndIndex);}
		else if(gameEndIndex<size){System.out.println("No "+gameEndIndex);}
	}

	}

}
