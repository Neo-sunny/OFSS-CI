package may17.circuits;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ZuluAndAlarmClock {

	public static void main(String[] args) {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		
	}
}
