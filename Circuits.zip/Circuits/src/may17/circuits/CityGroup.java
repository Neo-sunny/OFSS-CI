package may17.circuits;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class CityGroup {
	
	public static void main(String[] args) throws IOException {
		BufferedReader bi = new BufferedReader(new InputStreamReader(System.in));
		String[] line= bi.readLine().split("\\s+");
		int num_cities=Integer.parseInt(line[0]);
		 int city_groups=Integer.parseInt(line[1]);
		 System.out.println(num_cities+" "+city_groups);
		 List<List<Integer>> li2= new ArrayList<>();
		 String line1;
		// for(int i=0; i<city_groups; i++){
		//	 while (( line1 = bi.readLine()) != null){
			for(int i=0; i<city_groups; i++){
				line1 = bi.readLine();
				 List<Integer> li = new ArrayList<Integer>();
				String[] val=line1.split("\\s+");
				if(Integer.parseInt(val[0])==0){
					li2.add(li);
					 System.out.println(li2);
				}else{int index=1;
					for(int j=0;j<Integer.parseInt(val[0]);j++){
						
						 li.add(Integer.parseInt(val[index]));
						 index++;
					 }
					 li2.add(li);
						 System.out.println(li2);
				}
			//}
		}
		String[] line2=bi.readLine().split("\\s+");
		String line3;
		int query=Integer.parseInt(line2[0]);
		int count=0,t1=0,t2=0;int val=city_groups/2;
		for(int k=0;k<query; k++){
			String[] QueryVals=bi.readLine().split("\\s+");
			int val1=Integer.parseInt(QueryVals[0]);
			int val2=Integer.parseInt(QueryVals[1]);
			for(List<Integer> l1:li2){
					if(l1.contains(val1)){ t1=count;} 
					if(l1.contains(val2)){	t2=count;}
					count++;
				}
		int time=Math.abs(t2-t1);
			if(time>val)
				System.out.println(city_groups-time);
			else
				System.out.println(time);
		
	}
	}
	
}