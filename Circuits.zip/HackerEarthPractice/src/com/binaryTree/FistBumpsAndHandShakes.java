package com.binaryTree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FistBumpsAndHandShakes {

	
	public static void main(String[] args) throws IOException{
		List<Integer> groups= new ArrayList();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int testcases=Integer.parseInt(br.readLine());  //2
		Map<String, Integer> counts =new HashMap<String, Integer>();
		
		for(int i=0; i<testcases; i++){
			
			long handshakes=0, fistBump=0;
			int number_of_soldiers= Integer.parseInt(br.readLine()); //3
			String[] num=br.readLine().split("\\s+"); //011
			
			for(int j=0; j<num.length; j++ ){
				if(counts.containsKey(num[j])){
					counts.put(num[j], counts.get(num[j])+1);
				}else{
					counts.put(num[j],  1);
				}
			}
			for(Map.Entry<String, Integer> fb: counts.entrySet()){
					fistBump+=getSumOfN(fb.getValue()-1);
			}
			System.out.println(counts.size());
			System.out.println(counts);
			Integer[] hsArr= counts.values().toArray(new Integer[0]);
			for(int k=0; k<hsArr.length; k++){
				for(int l=k+1; l<hsArr.length; l++){
					handshakes+=hsArr[k]*hsArr[l];
				}
			}
			
			System.out.println(handshakes+" "+fistBump);
			counts.clear();
			/*
			for(int k=0; k<groups.size(); k++){
				fistBump+=getSumOfN(groups.get(k)-1);
				for(int l=k+1; l<groups.size(); l++){handshakes=groups.get(k)*groups.get(l); }
			}
			System.out.println(handshakes+" "+fistBump);
			groups.clear();*/
		}
	}
	
	static long  getSumOfN(long n){
		Integer sum= 0;
		for(int i=1; i<=n;i++){
			sum+=i;
		}
		return sum;
	}
	
	
}
