package com.binaryTree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class MirrorImage {

	
	public static void main(String[] args) throws IOException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String[] line1=br.readLine().split("\\s+");
		int n= Integer.parseInt(line1[0]);
		int q= Integer.parseInt(line1[1]);
		Map<Integer, Node> nodeMap= new HashMap<>();
		for(int i=0; i<n-1; i++){
			String[]	linei=br.readLine().split("\\s+");
			int root=Integer.parseInt(linei[0]);
			int value=Integer.parseInt(linei[1]);
			String pos= linei[2];
			if(pos.equals("R")){
				createMapForRightchild(root, value, nodeMap);
			}else if(pos.equals("L")){
				createMapForLeftchild(root, value, nodeMap);
			}
		}
		Node root =nodeMap.get(1);
		System.out.println(root.value);
		for(int j=0; j<q; j++){
			int value=Integer.parseInt(br.readLine());
			Node result=findMirrorImage(root, value, root);
			if(result== null){
				System.out.println(-1);
			}else 
				System.out.println(result.value);
		}
	}

	static Node findMirrorImage(Node  root, int val, Node result){
		if(root== null){
			return null;
		}if(root.value == val ){
			return result;
		}
		
		Node left = root.right==null?null:findMirrorImage(root.left, val, result.right);
		Node right= root.left==null?null:findMirrorImage(root.right, val, result.left);
		if(left!=null){
			return left;
		}else if(right!=null){
			return right;
		}else{
			return null;
		}
	}
	static void createMapForLeftchild(Integer parent,Integer child, Map<Integer, Node> nodeMap){
		if(nodeMap.get(parent)== null){
			Node node= new Node(parent);
			node.left=new Node(child);
			nodeMap.put(parent, node);
			nodeMap.put(child, node.left);
		}else if(nodeMap.get(parent)!= null){
			Node node= nodeMap.get(parent);
			node.left=new Node(child);
			nodeMap.put(child, node.left);
		}
	}
	static void createMapForRightchild(Integer parent,Integer child, Map<Integer, Node> nodeMap){
		if(nodeMap.get(parent)== null){
			Node node= new Node(parent);
			node.right=new Node(child);
			nodeMap.put(parent, node);
			nodeMap.put(child, node.right);
		}else if(nodeMap.get(parent)!= null){
			Node node= nodeMap.get(parent);
			node.right=new Node(child);
			nodeMap.put(child, node.right);
		}
	}
	public static class Node{
		int value;
		Node left;
		Node right;
		public Node(int val){
			this.value=val;
		}
	}
}
