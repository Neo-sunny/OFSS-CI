package com.arrays.oneD;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class MemoriseMe {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int n = Integer.parseInt(br.readLine());
		String[] str= br.readLine().split("\\s+");
		Map count= new HashMap<String,Integer>();
		for(String s:str){
			if(count.containsKey(s)){
				count.put(s, ((Integer)count.get(s)+1));
			}else{
				count.put(s, 1);
			}
		}
		
		int queries= Integer.parseInt(br.readLine());
		for(int i=0; i<queries; i++){
			String val=br.readLine();
			if(count.containsKey(val)){
				System.out.println(count.get(val));
			}else{
				System.out.println("NOT PRESENT");
			}
			
		}
		
	}
}
