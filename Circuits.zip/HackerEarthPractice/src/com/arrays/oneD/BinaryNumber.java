package com.arrays.oneD;

import java.util.LinkedList;
import java.util.List;

public class BinaryNumber {

	public static void main(String[] args) {
		System.out.println(1<<26);
		for(int i=1; i<=26; i++){
			System.out.println(1<<i);
		}
		List l1= new LinkedList<>();
	}
}
