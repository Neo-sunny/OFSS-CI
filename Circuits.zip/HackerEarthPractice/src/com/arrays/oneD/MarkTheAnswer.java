package com.arrays.oneD;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MarkTheAnswer {

	public static void main(String[] args) throws IOException{
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in)); 
		
		String[] firstLine= br.readLine().split("\\s+");
		int numQueries= Integer.parseInt(firstLine[0]);
		int difficultyLevel=Integer.parseInt(firstLine[1]);
		
		String[] qnArray=br.readLine().split("\\s+");
		int solvedQns=0, skip=0;
		for(String s:qnArray){
			int q1= Integer.parseInt(s);
			
			if(q1<=difficultyLevel && skip<=1){
				solvedQns++;
			}else if(q1>difficultyLevel){
				skip++;
				if(skip>1){	break; }
			}
		}
		System.out.println(solvedQns);
	}
}
