package com.arrays.oneD;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BinaryQueries {
	
public static void main(String[] args) throws IOException{
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	String[] input= br.readLine().split("\\s+");
	int n= Integer.parseInt(input[0]);
	int q=Integer.parseInt(input[1]);
	String[] inputBits= br.readLine().split("\\s+");
	for(int i=0; i<q; i++){
	String[] q1=br.readLine().split("\\s+"); // Query Input 
	if(Integer.parseInt(q1[0])==1){
		if(inputBits[Integer.parseInt(q1[1])-1]=="1"){
			inputBits[Integer.parseInt(q1[1])]="0";
			for(String s:inputBits){
				System.out.print(s);
			}
		}else{
			inputBits[Integer.parseInt(q1[1])-1]="1";
			for(String s:inputBits){
				System.out.print(s);
			}
		}
		
	}else if(Integer.parseInt(q1[0])==0){
		int r=Integer.parseInt(q1[q1.length-1]);
		int l=Integer.parseInt(q1[1]);
		 if(inputBits[r-1].equals("0")){
		System.out.println("EVEN");
		}
		else if(inputBits[r-1].equals("1")){
			System.out.println("ODD");}
	}
}
}
}
