package com.codemonk;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

public class DhoniHolidays {

// 0)REST
// 1)Academy / rest
// 2)Drive-Car/ rest
// 3)Drive-Car Academy	/ rest
	
	static Map<Integer, LinkedList<String>> work= new HashMap<Integer, LinkedList<String>>();
	static LinkedList<String> val0= new LinkedList(); 
	static LinkedList<String> val1= new LinkedList();
	static LinkedList<String> val2= new LinkedList();
	static LinkedList<String> val3= new LinkedList();
	static LinkedList<Integer> inputvals= new LinkedList(); 

	public static void main(String[] args) {
		int restCount=0;
		int prevVal=0;
		val0.add("rest");
		val1.add("academy");
		val2.add("drivecar");
		val3.add("academy");val3.add("drivecar");
		work.put(0, val0);
		work.put(1, val1);
		work.put(2, val2);
		work.put(3, val3);
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of holidays");
		int n= input.nextInt();
		for(int i=0; i<n; i++){
			int j= input.nextInt();
			inputvals.add(j);
		}
		System.out.println(work);
		for(int i=0; i<inputvals.size(); i++){
			if(inputvals.get(i)==0){
				restCount++;
				prevVal=0;
				work.put(0, val0);
			}
			else if(inputvals.get(i)==1 && !(work.get(prevVal).equals("academy"))   ){
				restCount++;
				prevVal=1;
				work.put(1, val1);
				System.out.println(work.get(prevVal));
			}else if(inputvals.get(i)==2 && !(work.get(prevVal).equals("drivecar"))   ){
				restCount++;
				prevVal=2;
				work.put(2, val2);
				System.out.println(work.get(prevVal));
			}else if(inputvals.get(i)==3    ){
				work.put(3, work.get(prevVal));
				prevVal=3;
				System.out.println(work.get(prevVal));
			}
		}
		System.out.println(restCount);
		}

}
