package com.codemonk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class MonkWalk {

	
	public static  int[] checkTree(String[] args){
		int[] ret = new int[args.length];
		int i, j=0, xount=0;
		for(String s: args){
			xount=0;
			char[] c= s.toCharArray();
			for( i=0; i<c.length; i++){
				if(c[i]=='A' ||c[i]=='E' ||c[i]=='I' ||c[i]=='O' ||c[i]=='U' ||c[i]=='a' ||c[i]=='e' ||c[i]=='i' ||c[i]=='o' ||c[i]=='u' ){
					xount++;
			}		
				}
			ret[j]=xount;	j++;		
		}
		return ret;
	}
	
	public static void main(String[] args) throws Exception {
		Long intTime= System.nanoTime();
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		
		//Scanner input= new Scanner(System.in);
		System.out.println("Enter the number of test Cases ");
		String testCase=br.readLine();
		int teCase=Integer.parseInt(testCase);
//		int tCases=input.nextInt();
		String[] arr= new String[teCase];
		for(int i=0; i<teCase;i++){
			System.out.println("Enter the test Case "+i);
			String vals=br.readLine();
			arr[i]=vals;
			
		}
		int[] returnArr=checkTree(arr);
		for(int i:returnArr){
			System.out.println(i);
		}
		Long finTime= System.nanoTime();
		Long TotTime=finTime-intTime;
		System.out.println(TotTime);
	}
}

 
