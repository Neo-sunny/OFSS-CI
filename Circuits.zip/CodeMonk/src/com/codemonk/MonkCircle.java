package com.codemonk;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
//1. Get the Co-Ordinates
//2. For each Co-Ordinates calculate the distance
//3. 
public class MonkCircle {

	static long[] co_dist;
	public static void main(String[] args) {
		int x=0,y=0;
		Scanner input=new Scanner(System.in);  
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		System.out.println(" Enter the number of points ");
		int NoOfpoints = input.nextInt();
	
		co_dist= new long[NoOfpoints];
		System.out.println("Enter the Co-ordinates ");
		for(int i=0;i<NoOfpoints;i++){			
				 x= input.nextInt();
				 y= input.nextInt();			
			co_dist[i] =calculateDistance(x,y);
		}		
		System.out.println("Enter the number of queries");
		int queries=input.nextInt();
		long[] res = new long[queries];
		for(int r=0; r<queries; r++){
			res[r]=calculateDistance1(input.nextInt());
		}
		for(long p:res){
			System.out.println(p);
		}	
	
	}
	static long calculateDistance1(int r){
		long count=0;
		for(long l:co_dist){
			if(l<=r*r){
				count++;
			}
		}
		return count;
	}

	static long calculateDistance(int x, int y){
		long d=(long)Math.exp(2 * Math.log(x)) +(long)(Math.exp(2 * Math.log(y)));		
		return d;
	} 
}
