package com.codemonk;

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class MonkSearch {	
	static long mod=1000000007;
	static int n;
	static int a[];
	static int bs1(int x)
	{
		int ans=-1;
		int f=0;
		int l=n-1;
		while(f<=l)
		{
			int m=f+l;
			m/=2;
			if(a[m]<x)
			{
				f=m+1;
			}
			else//a[m]>x
			{
				ans=m;
				l=m-1;
			}
			
		}
		return ans;
	}
	static int bs2(int x)// a=0
	{
		int ans=-1;
		int f=0;
		int l=n-1;
		while(f<=l)
		{
			int m=f+l;
			m/=2;
			if(a[m]<=x)
			{
				f=m+1;
			}
			else
			{
				ans=m;
				l=m-1;
			}
			
		}
		return ans;
	}
	public static void main(String[] args) throws  IOException {
		Long initTime= System.nanoTime();
		Scanner input= new Scanner(System.in);
		System.out.println("Entyer the size of Array");
		int size= input.nextInt();
		int[] arr = new int[size];
		
		System.out.println("Enetr the elements fo Arary");
		for(int i=0; i<size; i++){
			arr[i]=input.nextInt();
		}
		System.out.println("Enetr the number of queries");
		int query=input.nextInt();
		int[] res = new int[query];
		for(int j=0; j<query; j++){
			System.out.println("Enter the query "+j);
			int a=input.nextInt();
			int b=input.nextInt();
			if(a==0){
				// find all the elements >=b
				// Get the element ==b or next-value greater than b 
				/*for(int c=0; c<arr.length; c++){
					if(arr[c]>=b){
						res[j]=arr.length-c;
						break;
					}else{
						res[j]=0;
					}
				}	int c=0;*/
				System.out.println(bs2(b));				
				
			}else if(a>0){
				//find all the elemnts >b
				/*for(int c=0; c<arr.length; c++){
						if(arr[c]>b){
							res[j]=arr.length-c;
							break;
						}
					}							
					}else{
						res[j]=0;
					}
				}*/System.out.println(bs1(b));
		
			}
		/*for(int r:res){
			System.out.println(r);
		}*/
		Long finTime= System.nanoTime();
		Long TotTime=finTime-initTime;
		System.out.println(TotTime);
	} 
	
	
}
}