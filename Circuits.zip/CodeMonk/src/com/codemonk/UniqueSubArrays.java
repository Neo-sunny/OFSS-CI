package com.codemonk;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class UniqueSubArrays {
	List<Integer> intList ;
	Set<Integer> set;
	Integer[] integerArray ;
	
	public void findWeight(int[] array){
	Set<Integer> returnedSet= convertToNonPrimitive(array);
		
	if(array.length==returnedSet.size()){
		findSum(array.length);
	}
	else if(set.size()<array.length){
		int arrylength=array.length;
		int sizeOfSet=set.size();
		while(sizeOfSet<arrylength){}
		calculateArrays(arrylength,sizeOfSet);
			sizeOfSet++;
		}
	}
	public void calculateArrays(int arrayLength, int setSize){
		int n=arrayLength, index=0, sum=0;
		while(n>setSize){
			Integer[] arr=	Arrays.copyOfRange(integerArray,  index,  setSize-1+index);
			if(isUnique(arr)){
				sum= sum+arr.length;
			}
			n--;
		}
	}
public boolean isUnique(Integer[] array){
	for(Integer intValue : array) {
	    intList.add(intValue);  // List of Values
	   	}
		set = new LinkedHashSet(intList);
		if(array.length==set.size()){
			return true;
		}else
			return false;
	
}	
	//converting an primitive Array to Non-Primitive	
	public Set<Integer>  convertToNonPrimitive(int[] array){
		intList = new LinkedList<Integer>();
		integerArray = new Integer[array.length];
		int index=0;
		for(int intValue : array) {
		    intList.add(intValue);  // List of Values
		    integerArray[index]=intValue; // non Primitive Array
		}
		set = new LinkedHashSet(intList);
		return set;
	}
public void findSum(int length){
	int sum=0, i=1;	
	for(int j=length; j>=1; j--){
		sum+=j*i;
		i++;
	}
	System.out.println(sum);
}	
	
	
	
	
	 public static void main(String[] args) {
		 UniqueSubArrays subArrays= new UniqueSubArrays();
		 int[] ar= {1, 2,3,4,5 };
		 subArrays.findWeight(ar);
	}
}
