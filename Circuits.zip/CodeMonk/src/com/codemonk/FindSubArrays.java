package com.codemonk;

import java.util.Arrays;

public class FindSubArrays {

	public static void main(String[] args) {
		Integer[] array={1,2,3,4,5};
		subArrayCombinations(array, 5);
	}
	
	public static void subArrayCombinations(Integer[] array, int index){
		
		for(int i=0; i<=index; i++){
			for(int j=i+1; j<=index;j++){
				Integer[] NsubArray= Arrays.copyOfRange(array, i, j);
				printArray(NsubArray);
			}
	}
	}
	
	public static void printArray(Integer[] array){
		for(int i:array){
			System.out.print(i);
		}System.out.println();
	}
}
