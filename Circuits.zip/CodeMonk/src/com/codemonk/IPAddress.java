package com.codemonk;

import java.util.Scanner;

public class IPAddress {

	public static void evaluateIP(String ip){
		boolean flag=false;
		String[] extensionRemoved = ip.split("\\.");
		if(extensionRemoved.length<4 || extensionRemoved.length>4){
			System.out.println("NO");
			return;
		}
		for(String tr:extensionRemoved){
			for(char ch:tr.toCharArray()){
				if(!Character.isDigit(ch)){
					System.out.println("NO");
					flag=true;
					break;
				}
			}
			
		}
		if(flag)
		System.out.println("YES");
		return;
		
	}
	
	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		System.out.println("Enter the Ip Address to be evaluated");
		String ipAdd= input.nextLine();
		evaluateIP(ipAdd);
		
	}
}
