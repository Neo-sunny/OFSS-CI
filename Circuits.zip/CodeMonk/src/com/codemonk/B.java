package com.codemonk;

public class B {

	
	static long mod=1000000007;
	static int n;
	static int a[];
	static int bs1(int x)
	{
		int ans=-1;
		int f=0;
		int l=n-1;
		while(f<=l)
		{
			int m=f+l;
			m/=2;
			if(a[m]<x)
			{
				f=m+1;
			}
			else//a[m]>x
			{
				ans=m;
				l=m-1;
			}
			
		}
		return ans;
	}
	static int bs2(int x)
	{
		int ans=-1;
		int f=0;
		int l=n-1;
		while(f<=l)
		{
			int m=f+l;
			m/=2;
			if(a[m]<=x)
			{
				f=m+1;
			}
			else
			{
				ans=m;
				l=m-1;
			}
			
		}
		return ans;
	}
}
