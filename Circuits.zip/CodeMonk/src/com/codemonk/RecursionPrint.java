package com.codemonk;

public class RecursionPrint {

	public static int print(int n){
		
		
		if(n>0){
			System.out.println(n);
			 print(n-1);
		}
		
		return n;
		
	}
	
	public static void main(String[] args) {
		
		print(10);
	}
}
