package com.codemonk.greedy;

import java.util.Scanner;

public class ExploringRuins {

/*   // ALWAYS CHECK FOR PREVIOUS CHARACTER
 * 1.) check whether every letter of string is character or not
 * 		a)if character then check whether it is 'a' or 'b'
 * 		b)if character is 'a' then NEXT character should be "b->a->b->a->b...  until u find a next character
 * 		c)if character is "b" then then next character should be "a->b->a->b..." until u find a next character
 * 2.) If not a character then replace with pattern ==> ababab
 * 
 * 	bababab
 * 
 * 
 * 
 * 
 * */ 
		public   void createWord(String input) {
		int i=0;
		char[] myChars = input.toCharArray();
		for(char c:input.toCharArray()){
			if(Character.isLetter(c)){			}			
		else{
		if(i==0 && input.length()==1){
			myChars[i]='a';
		}
		else if(i==0 && input.length()>1){
			char ch=myChars[i+1];
			if(ch=='a'){
				myChars[i]='b';
			}else{
				myChars[i]='a';}
		}//else{
		else if(i<input.length()-1){
			if(myChars[i-1]=='a'){
			myChars[i]='b';
		}else if(myChars[i-1]=='b' && myChars[i+1]=='a'){
			myChars[i]='b';
		}else if(myChars[i-1]=='b' && myChars[i+1]=='?'){
			myChars[i]='a';
		}else if(myChars[i-1]=='b' && myChars[i+1]=='b'){
			myChars[i]='a';
		}
		}else{
			if(myChars[i-1]=='b'){myChars[i]='a';}
			else{myChars[i]='b';}
		}}
			i++;
		}
		System.out.println(myChars);
	}
	
	public static void main(String[] args)  {
		Scanner input= new Scanner(System.in);
		System.out.println("Enter the  string");
		String inputStr = input.nextLine();
		ExploringRuins ruins= new ExploringRuins();
		ruins.createWord(inputStr);
	}

}
