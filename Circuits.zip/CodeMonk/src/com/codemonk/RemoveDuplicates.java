package com.codemonk;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicates {

	
	public static void main(String [] args){
		int[] arr=  {50,60,100,80,70,60,90};
		Arrays.sort(arr);
		Set linhas= new LinkedHashSet<>();
		for(int i:arr){
		linhas.add(i);
	}
		System.out.println(linhas.toArray(new Integer[0]));
		Integer[] y = (Integer[]) linhas.toArray(new Integer[0]);
		System.out.println(y.length);
		List<Integer> al= Arrays.asList(y); 
	 
	System.out.println(al);
		for(Integer i:y){
			System.out.println(i);
		}
	}
}
