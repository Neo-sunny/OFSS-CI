package com.hackerearth.amazon;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputfromKeyboard {

	
	public static void main(String[] args) throws IOException {
		BufferedReader input= new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the value from keyboard");
		String inputString = input.readLine();
		int num = Integer.parseInt ( inputString );
		System.out.println(num);
		int[] arr= new int[num];
		for (int i=0;i<num;i++){
			String inputString1 = input.readLine();
			arr[i] = Integer.parseInt ( inputString1 );
		}
		
		for (int i=0;i<num;i++){
			System.out.println(arr[i]);
		}
	}
}
