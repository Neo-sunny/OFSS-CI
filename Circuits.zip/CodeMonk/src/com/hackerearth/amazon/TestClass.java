package com.hackerearth.amazon;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

class TestClass {
    public static void main(String[] args)throws IOException  {
	BufferedReader input1=new BufferedReader(new InputStreamReader(System.in));
		String inputString = input1.readLine();
		int testCases1 = Integer.parseInt ( inputString );
		/*For each testCases we need the length of array 
		 * as well as the elements of array
		 * 
		 * */
		for(int j=1; j<=testCases1; j++){
	String inputString2 = input1.readLine();
		int length1 = Integer.parseInt ( inputString2 );
		long[] array= new long[length1];
		for (int i=0;i<length1;i++){
			String inputString1 = input1.readLine();
		
		array[i] = 	Long.parseLong(inputString1);
			
		}
		getTheArrays(array, length1);
		}
	}
	public static void getTheArrays(long[] array, int length){
		int totalsubArrays= length*(length+1)/2;
		int val=0;
		long[] valArray= new long[totalsubArrays];
		for(int i=0; i<length;i++){
			for(int j=i;j<=length;j++){
				long[] subArray=Arrays.copyOfRange(array, i, j);
					if(subArray.length>=1){
					long retXorVal=findXOR(subArray);
					valArray[val]=retXorVal;
					val++;
					
				}
					
			}
		}
		
	
		System.out.println(findXOR(valArray));
	}
	
	public  static long findXOR(long[] subArr){
		long xorVal= 0;
	  if(subArr.length==1){
		  return subArr[0];
	  }else if(subArr.length>1){
		  int length=subArr.length;
		  
		  for(int i=0; i<length; i++){
			  xorVal=xorVal^subArr[i];
		  }
		 
	  }
	  return xorVal;
	}
}
