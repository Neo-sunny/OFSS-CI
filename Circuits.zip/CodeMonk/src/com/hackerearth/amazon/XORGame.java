package com.hackerearth.amazon;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Scanner;

public class XORGame {
	
// static	int totalsubarray= (length*length+1)/2;
	public static void getTheArrays(long[] array, int length){
		int totalsubArrays= length*(length+1)/2;
		int val=0;
		long[] valArray= new long[totalsubArrays];
		for(int i=0; i<length;i++){
			for(int j=i;j<=length;j++){
				long[] subArray=Arrays.copyOfRange(array, i, j);
					if(subArray.length>=1){
					long retXorVal=findXOR(subArray);
					valArray[val]=retXorVal;
					val++;
					System.out.println("XOR value for the given subArray"+retXorVal);
				}
					
			}
		}
		
		printArray(valArray);
		System.out.println("Final XOR value "+findXOR(valArray));
	}
	
	public  static long findXOR(long[] subArr){
		long xorVal= 0;
	  if(subArr.length==1){
		  return subArr[0];
	  }else if(subArr.length>1){
		  int length=subArr.length;
		  
		  for(int i=0; i<length; i++){
			  xorVal=xorVal^subArr[i];
		  }
		 
	  }
	  return xorVal;
	}
	
	public static void printArray(long[] array){
		for(int i=0; i<array.length; i++){
			System.out.print(array[i]);
		}
		System.out.println();
	}
	public static void main(String[] args) throws IOException {
	//	Scanner input= new Scanner(System.in);
		BufferedReader input1=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number of testcases");
	//	int testCases= input.nextInt();
		String inputString = input1.readLine();
		int testCases1 = Integer.parseInt ( inputString );
		/*For each testCases we need the length of array 
		 * as well as the elements of array
		 * 
		 * */
		for(int j=1; j<=testCases1; j++){
		System.out.println("Enter the length of array");
	//	int length=input.nextInt();
		String inputString2 = input1.readLine();
		int length1 = Integer.parseInt ( inputString2 );
		long[] array= new long[length1];
		for (int i=0;i<length1;i++){
		System.out.println("Enter the "+(i+1)+"element");
		String inputString1 = input1.readLine();
	
		//array[i] = Integer.parseInt ( inputString1 );
		array[i] = Long.parseLong(inputString1);
		}
		//printArray(array);
		getTheArrays(array, length1);
		}
	}
}
