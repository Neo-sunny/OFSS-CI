package com.hackerearth.amazon;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.omg.PortableServer.AdapterActivator;

public class JeffBtrucker {

	Map<Integer, List<Integer>> adjacentList;
	
	public JeffBtrucker(int noOfVertices){
	//	HashMap<Integer, List<Integer>>();
		adjacentList= new HashMap<Integer, List<Integer>>();
		for(int i=1; i<=noOfVertices;i++){
			adjacentList.put(i, new LinkedList<Integer>());			
		}
	}
	public void createEdgeHelper(int noOfVertices){
		
		for(int i=1;i<=noOfVertices;i++){
			for(int j=i; j<=noOfVertices;j++){
				if(i!=j){
					createEdge(i,j);	
				}
			}
		}
	}	
public void createEdge(int source, int destination){
		if (source > adjacentList.size() || destination > adjacentList.size())
	       {
	           System.out.println("the vertex entered in not present ");
	           return;
	       }
		List slist=  adjacentList.get(source);
		slist.add(destination);
		List dlist=  adjacentList.get(destination);
		dlist.add(source);
}	


public void removeEdge(int source, int destination){
	List slist=  adjacentList.get(new Integer(source));
	slist.remove(new Integer(destination));
	List dlist=  adjacentList.get(new Integer(destination));
	dlist.remove(new Integer(source));
}	
public static void main(String[] args) {
	Scanner input= new Scanner(System.in);
	System.out.println("Enter the number of testCases ");
	int tCases=input.nextInt();
	// For each Test Case Enter the number of Customers and PuKKa paths
	for(int i=0;i<tCases;i++){
		System.out.println("Enter the number of customers and pukka path");
		int nOfCust=input.nextInt();
		int pukkaRoads=input.nextInt();
		JeffBtrucker obj1= new 	JeffBtrucker(nOfCust);
		obj1.createEdgeHelper(nOfCust);
		System.out.println(obj1.adjacentList);
		for(int j=0; j<pukkaRoads;j++){
		System.out.println("Enter the pakka paths");
		int p1=input.nextInt();
		int p2=input.nextInt();
		obj1.removeEdge(p1, p2);
		}
		System.out.println(obj1.adjacentList);
	}
}	
	
	
	
	
	
	
	
	
}
