package com.practice.bp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class SevenSegmentDisplay {

	static Map<Integer, Integer> segDisp= new HashMap<Integer, Integer>();
	static	Map<Integer, Integer> values= new HashMap<Integer, Integer>();
	
	 static void createSegmentsdisplays(){
		 segDisp.put(1, 2);
		 segDisp.put(2, 5);
		 segDisp.put(3, 5);
		 segDisp.put(4, 4);
		 segDisp.put(5, 5);
		 segDisp.put(6, 6);
		 segDisp.put(7, 3);
		 segDisp.put(8, 7);
		 segDisp.put(9, 6);
		 segDisp.put(0, 6);
	 }
	/*
	 * 1. For each Array find the Minimum value
	 * 2. If there are more than one elements for the minimum value, find the first occurrence
	 * */
	public static void findJarvis(int[] listElements){
		int[] newArr = new int[listElements.length];
		
		for(int i=0; i<listElements.length; i++){
			values.put(listElements[i], segDisp.get(listElements[i]));
		}
//		getMinKey(values);
		
	}
	
	
	public static void  findMinVal(Map<Integer, Integer> values){
		int min=Collections.min(values.values());
		Entry<Integer, Integer> minm = null;
		for (Entry<Integer, Integer> entry : values.entrySet()) {
		    if (minm == null || minm.getValue() > entry.getValue()) {
		    	minm = entry;
		    }
		}

		System.out.println("the Minimum Value "+minm.getKey());
		
		
		
	}
	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		System.out.println("Enter the number of test cases");
		int testcases= input.nextInt();
		for(int i=0;i<testcases; i++){
			System.out.println("enter the length of list");
			int listSize=input.nextInt();
			int[] elements= new int[listSize];
			for(int j=0;j<listSize; j++ ){
				System.out.println("Enter the list element"+(i+1));
				elements[j]=input.nextInt();
				}
			findJarvis(elements);
		}
	}
}
