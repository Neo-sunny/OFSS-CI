package com.march.circuits;

import java.util.Scanner;

public class XORect1 {
	//int x_i_j = matrix[ i*COLS + j ];
	//int x_i_j = matrix[i][j];
	static int[] createMatrix(int[] intArray){
		int matrixSize= intArray.length;		
		int[] matrix= new int[matrixSize*matrixSize];
		for(int i=0; i<matrixSize;i++){
			for(int j=0; j<matrixSize; j++){
	
				 matrix[ i*matrixSize + j ]=intArray[i]^intArray[j];
			}
		}
		return matrix;
	}
	static void createSubMatrix(int[] matrix, int x1, int x2, int y1, int y2, int size ){
		int sum=0;
		for(int i=x1; i<=y1;i++){
			for(int j=x2; j<=y2; j++){
				sum=sum+matrix[ i*matrix.length/size + j];
			}
		}
		System.out.println(sum);
	}
	static void printmatrix(int[] matrix){
		for(int i=0; i<matrix.length/4;i++){
			for(int j=0; j<matrix.length/4; j++){
				System.out.print(matrix[i*matrix.length/4 + j]);
			}
			System.out.println();
			}
	}
	
	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size=input.nextInt();
		int[] array= new int[size];
		for(int j=0; j<size;j++){
			System.out.println("Enter the "+(j+1)+"element of array");
			array[j]=input.nextInt();
			}
		int[] matrix=createMatrix(array);
	//	printmatrix(matrix);
		System.out.println("Enter the number of queries");
		int queries=input.nextInt();
		for(int i=0; i<queries;i++){
			System.out.println("Enter the elements of the first matrix");
			int x1=input.nextInt();
			int x2=input.nextInt();
			int y1=input.nextInt();
			int y2=input.nextInt();
			createSubMatrix(matrix,--x1,--x2,--y1,--y2, size);
		}
		
}
}