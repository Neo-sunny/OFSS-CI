package com.dijkstra;

public class Edge {
	Vertex source;
	Vertex destination;
	int weight;
	
	public Edge(Vertex s, Vertex d, int w){
		this.source=s;
		this.destination=d;
		this.weight=w;
	}
	
	public Vertex getSource() {
		return source;
	}
	public void setSource(Vertex source) {
		this.source = source;
	}
	public Vertex getDestination() {
		return destination;
	}
	public void setDestination(Vertex destination) {
		this.destination = destination;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
	
}
