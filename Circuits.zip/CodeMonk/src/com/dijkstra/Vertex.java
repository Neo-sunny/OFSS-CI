package com.dijkstra;

public class Vertex {
	int node;

	public Vertex(int node){
		this.node=node;
	}
	public Vertex(){
	}
	
	public int getNode() {
		return node;
	}

	public void setNode(int node) {
		this.node = node;
	}

	
	
	
}
