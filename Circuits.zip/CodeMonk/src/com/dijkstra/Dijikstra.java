package com.dijkstra;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Dijikstra {
	
	
	private Set<Vertex> settledNodes;
	private Set<Vertex> neNodes;
    private Set<Vertex> unSettledNodes;
    private Map<Vertex, Vertex> parentMap;
    private Map<Vertex, Integer> distance;
	List<Vertex> nodes;
	List<Edge> edges;
	public Dijikstra(){}
	public Dijikstra(Graph graph){
		this.nodes=new LinkedList<Vertex>(graph.getNodes());
		this.edges= new LinkedList<Edge>(graph.getEdges());
	}

public void useDijikstra(Vertex source){
	settledNodes = new HashSet<Vertex>();
	neNodes=  new HashSet<Vertex>();
    unSettledNodes = new HashSet<Vertex>();
    distance = new HashMap<Vertex, Integer>();
    parentMap = new HashMap<Vertex, Vertex>();
    distance.put(source, 0);
    unSettledNodes.add(source);
      while(unSettledNodes.size()>0){
    	for(Vertex v: unSettledNodes ){
    		 settledNodes.add(v);
        	 unSettledNodes.remove(v);
        	 neNodes= findNeighbourNodesWithDistance(v);
             Vertex currNode=  findNodeWithLowestdistance(neNodes);
             parentMap.put(v, currNode);
             unSettledNodes.add(currNode);
        }
    }
    
}


public Vertex  findNodeWithLowestdistance(Set<Vertex> nodes){
	Vertex minimum=null;
	int minDist=Integer.MAX_VALUE;
	for(Vertex v:nodes){
		if(distance.get(v)<minDist){
			minDist=distance.get(v);
			minimum=v;
		}
	}
	return minimum;
}
public Set<Vertex> findNeighbourNodesWithDistance(Vertex source){
	LinkedList<Vertex> neighbours =	getNeighbours(source);
	Set<Vertex> neighbourNodes=new HashSet<Vertex>();
	for(Vertex target:neighbours){
			// for each node get the distance from source to destination and weight for each node
		int d1=getDistance(target);
		int d2=getDistance(source);
		int weight=getWeight(source, target);
		if(d1>d2+weight){
			distance.put(target, d2+weight);
			neighbourNodes.add(target);
			}		
// 		
	}
	return neighbourNodes;
}
public int getWeight(Vertex source, Vertex target){
	
	int weight=0;
	for(Edge e:edges){
		if(e.getSource().equals(source) && e.getDestination().equals(target)){
			weight= e.getWeight();
		}
	}
	return weight;
}
public int getDistance(Vertex node){
	Integer d = distance.get(node);
    if (d == null) {
            return Integer.MAX_VALUE;
    } else {
            return d;
    }
}
public LinkedList<Vertex> getNeighbours(Vertex node){
	LinkedList<Vertex> neighbours= new LinkedList() ;
	for(Edge e:edges){
		if(e.getSource().equals(node)  && !isVisited(e.getDestination())){
			neighbours.add(e.getDestination());
		}else if(e.getDestination().equals(node)  && isVisited(e.getDestination())){
			neighbours.add(e.getDestination());
		}
	}
	
	return neighbours;
}
boolean isVisited(Vertex vertex){
	return settledNodes.contains(vertex);
}

}
