package com.dijkstra;

public class TestMaxValSum {

	
	public static void main(String[] args) {
		Integer d=Integer.MAX_VALUE;
		Integer c=4;
		Integer sum= d+c;
		System.out.println();
		System.out.println(sum);
	}
}
