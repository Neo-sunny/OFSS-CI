package com.dijkstra;

import java.util.ArrayList;
import java.util.List;

public class DijMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	List<Vertex> n= new ArrayList<Vertex>();	
	List<Edge> e= new ArrayList<Edge>();	
	
Vertex v0= new Vertex(0);Vertex v1= new Vertex(1);	Vertex v2= new Vertex(2);	Vertex v3= new Vertex(3);	Vertex v4= new Vertex(4);		
Vertex v5= new Vertex(5);Vertex v6= new Vertex(6);	Vertex v7= new Vertex(7);	Vertex v8= new Vertex(8);	
n.add(v0);n.add(v1); n.add(v2);n.add(v3);	n.add(v4); n.add(v5); n.add(v6); n.add(v7);
n.add(v8);
Edge e1=new Edge(v0,v1, 4);		
Edge e2=new Edge(v1,	v2, 8);		
Edge e3=new Edge(v2,	v3, 7);		
Edge e4=new Edge(v3,	v4, 9);		
Edge e5=new Edge(v4,	v5, 10);		
Edge e6=new Edge(v5,	v6, 2);		
Edge e7=new Edge(v6,	v7, 1);		
Edge e8=new Edge(v7,	v8, 7);		
Edge e9=new Edge(v7,	v1, 11);		
Edge e10=new Edge(v8,	v2, 2);		
Edge e11=new Edge(v8,	v6, 6);		
Edge e12=new Edge(v5,	v2, 4);
Edge e13=new Edge(v5,	v3, 14);
Edge e14=new Edge(v0,	v7, 8);
e.add(e1); e.add(e2);	e.add(e3); e.add(e4);	e.add(e5); e.add(e6);
e.add(e7); e.add(e8);	e.add(e9); e.add(e12);	e.add(e10); e.add(e13);
e.add(e11); e.add(e14);

Graph g1= new Graph(n, e);
Dijikstra dijikstra= new Dijikstra(g1);
dijikstra.useDijikstra(v0);
	}

}
